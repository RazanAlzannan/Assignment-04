import Foundation
/*:
 ## Struct Lab - Tuwaiq Bootcamp

 Create a struct called Book that contains the following properties:

 - title: a String representing the title of the book
 - author: a String representing the author of the book
 - pages: an integer representing the number of pages in the book
 - topic: a String representing the topic or genre of the book (e.g. Computer Science, Programming, Self-Development, etc.)
 
 */
struct Gener {
    var topic : String
    init(topic : String){
        self.topic = topic
    }
}

struct Book {
    var title : String
    var author : String
    var pages : Int
    var topic : Gener
    
    init(title : String, author : String, pages : Int, topic : Gener ) {
        self.title = title
        self.author = author
        self.pages = pages
        self.topic = topic
    }

}


/*:
 Create an array of type Book and populate it with at least 3 books using a loop.
 */
var books : [Book] = [Book(title: "Clean Code: A Handbook of Agile Software Craftsmanship",
                           author: "Robert C. Martin", pages: 340,
                           topic: Gener(topic: "Programming")),
                      Book(title: "Cracking the Coding Interview: 189 Programming Questions and Solutions",
                           author: "Gayle Laakmann McDowell", pages: 506,
                           topic: Gener(topic: "Programming")),
                      Book(title: "Artificial Intellignce Q", author: "Nick polosn and James Scott", pages: 280,   topic: Gener(topic: "AI")),
                      Book(title: "Team Work Skills", author: "Walter A. Sedrek", pages: 470,   topic: Gener(topic: "Self-Development")),
                      Book(title: "AI in our daily Life", author: "Dr. Razan M.", pages: 480,   topic: Gener(topic: "AI")),
                      Book(title: "How to become rich?", author: "Saleh J.", pages: 345,   topic: Gener(topic: "Self-Development")),]
 
print("*** New Books in the Store ***")
for i in books {
    print("------------")
    print("Book Title : \(i.title) by \(i.author) ")
}
/*:
 Then, write a function called printBooksInTopic that takes two arguments: the array of books and a topic as a String. The function should print out the title and author of each book in the array that matches the specified topic.
 */

func printBooksInTopic(_ Books : [ Book ], topic : String){
    print("------------")
    print("*** Books in \(topic) ***")
    for i in Books{
        if i.topic.topic == topic {
            print("- \(i.title) by \(i.author)")
        }
    }
}

// Example usage:
printBooksInTopic( books , topic: "Programming")
printBooksInTopic(books, topic: "AI")
printBooksInTopic(books, topic: "Self-Development")
